import zipfile
import pandas as pd
import os
import chardet

print("=== IMDb India Movie Analysis ===\n")

ZIP_FILE = "IMDb Movies India.csv.zip"

# Step 1: Check and extract ZIP
if os.path.exists(ZIP_FILE):
    print(f"Found ZIP file: {ZIP_FILE}, extracting...")
    with zipfile.ZipFile(ZIP_FILE, 'r') as zip_ref:
        zip_ref.extractall(".")
    print("Extraction complete.\n")
else:
    raise FileNotFoundError(f"ZIP file {ZIP_FILE} not found.")

# Step 2: Find CSV
csv_files = [f for f in os.listdir(".") if f.lower().endswith(".csv")]
if not csv_files:
    raise FileNotFoundError("No CSV file found after extracting ZIP.")

CSV_FILE = csv_files[0]
print(f"Using CSV file: {CSV_FILE}\n")

# Step 3: Detect encoding
with open(CSV_FILE, 'rb') as f:
    raw_data = f.read(100000)  # read first 100 KB
    result = chardet.detect(raw_data)
    detected_encoding = result['encoding']
    print(f"Detected encoding: {detected_encoding}")

# Step 4: Load CSV with detected encoding
try:
    df = pd.read_csv(CSV_FILE, encoding=detected_encoding)
    print("\nData loaded successfully!\n")
    print(df.head())
except Exception as e:
    print(f"Error reading CSV: {e}")
    raise

# Step 5: Basic info
print("\n=== Dataset Info ===")
print(df.info())
print("\n=== Missing Values ===")
print(df.isnull().sum())
